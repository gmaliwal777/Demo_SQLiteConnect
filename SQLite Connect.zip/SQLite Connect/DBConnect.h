//
//  DBConnect.h
//  Y-LogApp
//
//  Created by Suman Sharma on 10/22/12.
//  Copyright (c) 2012 SS Global LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "sqlite3.h"

@interface DBConnect : NSObject
{
    sqlite3         *database;
    sqlite3_stmt    *statement;
    NSString        *dbName;
}

@property(nonatomic ,assign) sqlite3        *database;
@property(nonatomic ,assign) sqlite3_stmt   *statement;
@property(nonatomic ,strong) NSString       *dbName;


/**
 *  Used to get SQLite Shared Instance
 *
 *  @return : Shared instance
 */
+(DBConnect *)sharedInstance;


/**
 *  Used get DB File path
 *
 *  @return : string DB File path
 */
-(NSString *)getDBFilePath;


//-(void)createCustomDB;


-(BOOL)checkNCreateDB;
-(BOOL)getConnection:(const char*)dbPath;

-(BOOL)closeConnection;
-(BOOL)updateQuery:(NSString *)sqlQuery;
-(int)insertQuery:(NSString *)sqlQuery;
-(int*)selectQuery:(NSString *)sqlQuery;
-(NSMutableArray *)executeQuery:(NSString *)query;

/**
 *  Used to insert records in Contacts in bulk
 *
 *  @param arrContacts : contacts container
 */
-(void)insertBatch:(NSArray *)arrContacts;


/**
 *  Used to update contacts for setting EXISTING = 'NO'
 *
 *  @param arrContacts : Contacts array container
 */
-(void)updateBatch:(NSArray *)arrContacts;

@end
