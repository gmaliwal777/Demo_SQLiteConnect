//
//  DBConnect.m
//  Y-LogApp
//
//  Created by Suman Sharma on 10/22/12.
//  Copyright (c) 2012 SS Global LLC. All rights reserved.
//

#import "DBConnect.h"
#import <sqlite3.h>
#import "DBContacts.h"


static DBConnect *_instance;

@implementation DBConnect

@synthesize database;
@synthesize statement;
@synthesize dbName;

-(void)dealloc{
    NSLog(@"calling dealloc of dbconnect");
    if (dbName != nil) {
        dbName = nil;
    }
}

/**
 *  Used to get shared Database Handler instance
 *
 *  @return : database handler instance
 */
+(DBConnect *)sharedInstance{
    if (_instance == nil) {
        _instance = [[self alloc]init];
        _instance.dbName = @"BOKU.sqlite";
        
        [_instance checkNCreateDB];
        
    }
    return _instance;
}


/**
 *  Used to create SQLite Statement
 *
 *  @param querySQL : statement query string
 *
 *  @return : YES if statement created successfully else NO
 */
-(BOOL)createStatement:(NSString *)querySQL{
    const char *dbquery = [querySQL UTF8String];
    NSLog(@"going texecutere query: %@",querySQL);
    if (sqlite3_prepare_v2(database,dbquery,-1,&statement,NULL)== SQLITE_OK) {
        NSLog(@"query is executed successfully");
        return YES;
    }else{
        NSLog(@"query is not executed successfully");
        return NO;
    }
}



/**
 *  Used to get DB File path
 *
 *  @return : string representation of DB path
 */
-(NSString*) getDBFilePath{

    NSString *DBFilePath = [NSTemporaryDirectory() stringByAppendingPathComponent:self.dbName];
    
    NSLog(@"Get Dbpath is %@",DBFilePath);
    return DBFilePath;
}


/**
 *  Used to check and create DB in App from Bundle
 *
 *  @return YES if task is done else NO
 */
-(BOOL)checkNCreateDB{
    
    NSString *docsPath =NSTemporaryDirectory();
    NSString *dbPath = [docsPath stringByAppendingPathComponent:self.dbName];
    NSLog(@"dbpath is %@",dbPath);
    
    //Now we are getting File Manager Object to determine Sqlite file existing in Document Directory
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:dbPath]) {
        //Control comes inside if DBFile is not existing and we are are copying that file in Document Directory
        NSString *dbPathInApp = [[NSBundle mainBundle] pathForResource:@"BOKU" ofType:@"sqlite"];
        
        //NSString *dbPathInApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:self.dbName];
        NSLog(@"Present dbpath in app is %@",dbPathInApp);
        
        bool flag = [fileManager copyItemAtPath:dbPathInApp toPath:dbPath error:nil];
        if (flag) {
            NSLog(@"file copied");
        }else{
            NSLog(@"file not copied");
        }
        [self addSkipBackupAttributeToItemAtPath:docsPath];
        return YES;
    }else{
        NSLog(@"not done");
        return NO;
    }
}


- (BOOL)addSkipBackupAttributeToItemAtPath:(NSString *)filePathString {
    //    NSLog(@"filePathString is %@",filePathString);
    NSURL *fileURL =
    [NSURL fileURLWithPath:filePathString];
    
    assert([[NSFileManager defaultManager]
            fileExistsAtPath: [fileURL path]]);
    NSError *error = nil;
    BOOL success = [fileURL setResourceValue:[NSNumber numberWithBool:YES]
                                      forKey:NSURLIsExcludedFromBackupKey
                                       error:&error];
    return success;
}

//Connect DB
-(BOOL)getConnection:(const char*)dbPath{
    if (sqlite3_open(dbPath,&database)== SQLITE_OK) {
        NSLog(@"Connection is openend successfully");
        return YES;
    }else{
        NSLog(@"Connection is not openend");
        return NO;
    }
}


//Close DB Connection
-(BOOL)closeConnection{
    
    if (sqlite3_close(database) == SQLITE_OK) {
        return YES;
    }else{
        return NO;
    }
}


//Method to Update Table
-(BOOL)updateQuery:(NSString *)sqlQuery{
    BOOL returnFlag= NO;
    NSString *dbFilePath = [self getDBFilePath];
   
    BOOL connectionFlag = [self getConnection:[dbFilePath UTF8String]];
    if (connectionFlag) {
       
        BOOL statementFlag = [self createStatement:sqlQuery];
        if (statementFlag==YES && sqlite3_step(statement) == SQLITE_DONE) {
            sqlite3_finalize(statement);
            returnFlag = YES;
        }else{
            returnFlag = NO;
        }
        [self closeConnection];
    }else{
        returnFlag = NO;
    }
    return returnFlag;
}

#pragma mark insert query
-(int)insertQuery:(NSString *)sqlQuery{
    int rowID = 0;
    NSString *dbFilePath = [self getDBFilePath];
    
    BOOL connectionFlag = [self getConnection:[dbFilePath UTF8String]];
    
    if (connectionFlag) {
        
        BOOL statementFlag = [self createStatement:sqlQuery];
        
        if (statementFlag==YES && sqlite3_step(statement) == SQLITE_DONE) {
            //Closing Statement Object
            //sqlite3_finalize(statement);
            
            rowID = sqlite3_last_insert_rowid(database);
            NSLog(@"last inserted rowId = %d",rowID);
        }
        
        sqlite3_finalize(statement);
        
        [self closeConnection];
    }
    return rowID;
}

/**
 *  Used to update contacts for setting EXISTING = 'NO'
 *
 *  @param arrContacts : Contacts array container
 */
-(void)updateBatch:(NSArray *)arrContacts{
    //getting DBPath
    NSString *dbFilePath = [self getDBFilePath];
    
    //getting Connection
    [self getConnection:[dbFilePath UTF8String]];
    
    //Begin Transaction
    NSString* query;
    query = @"BEGIN EXCLUSIVE TRANSACTION";
    sqlite3_stmt *beginStatement;
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &beginStatement, NULL) != SQLITE_OK) {
        printf("db error: %s\n", sqlite3_errmsg(database));
        return;
    }
    
    if (sqlite3_step(beginStatement) != SQLITE_DONE) {
        sqlite3_finalize(beginStatement);
        printf("db error: %s\n", sqlite3_errmsg(database));
        return;
    }
    
    query = @"UPDATE CONTACTS SET EXISTING = 'NO' WHERE UNIQUE_ID = ? AND PHONE = ?";
    
    sqlite3_stmt *compiledStatement;
    if(sqlite3_prepare_v2(database, [query UTF8String], -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        for(int i = 0; i < [arrContacts count]; i++){
            DBContacts *contact = [arrContacts objectAtIndex:i];
            
            //sqlite3_bind_int64(compiledStatement, 1, [contact.UNIQUE_ID integerValue]);
            sqlite3_bind_text(  compiledStatement, 1, [contact.UNIQUE_ID UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(  compiledStatement, 2, [contact.PHONE UTF8String], -1, SQLITE_TRANSIENT);
            
            while(YES){
                NSInteger result = sqlite3_step(compiledStatement);
                if(result == SQLITE_DONE){
                    break;
                }else if(result != SQLITE_BUSY){
                    printf("db error: %s\n", sqlite3_errmsg(database));
                    break;
                }
            }
            sqlite3_reset(compiledStatement);
        }
        
        
        // COMMIT
        query = @"COMMIT TRANSACTION";
        sqlite3_stmt *commitStatement;
        if (sqlite3_prepare_v2(database, [query UTF8String], -1, &commitStatement, NULL) != SQLITE_OK) {
            printf("db error: %s\n", sqlite3_errmsg(database));
        }
        if (sqlite3_step(commitStatement) != SQLITE_DONE) {
            printf("db error: %s\n", sqlite3_errmsg(database));
        }
        
        sqlite3_finalize(beginStatement);
        sqlite3_finalize(compiledStatement);
        sqlite3_finalize(commitStatement);
        
        [self closeConnection];
    }
    
}

/**
 *  Used to insert records in Contacts in bulk
 *
 *  @param arrContacts : contacts container
 */
-(void)insertBatch:(NSArray *)arrContacts{
    
    //getting DBPath
    NSString *dbFilePath = [self getDBFilePath];
    
    //getting Connection
    [self getConnection:[dbFilePath UTF8String]];
    
    
    //Begin Transaction
    NSString* query;
    query = @"BEGIN EXCLUSIVE TRANSACTION";
    sqlite3_stmt *beginStatement;
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &beginStatement, NULL) != SQLITE_OK) {
        printf("db error: %s\n", sqlite3_errmsg(database));
        return;
    }
    
    if (sqlite3_step(beginStatement) != SQLITE_DONE) {
        sqlite3_finalize(beginStatement);
        printf("db error: %s\n", sqlite3_errmsg(database));
        return;
    }
    
    
    query = @"INSERT OR REPLACE INTO CONTACTS (UNIQUE_ID,PHONE,SYNCED) VALUES(?,?,?)";
    
    sqlite3_stmt *compiledStatement;
    if(sqlite3_prepare_v2(database, [query UTF8String], -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        for(int i = 0; i < [arrContacts count]; i++){
            DBContacts *contact = [arrContacts objectAtIndex:i];
            
            //sqlite3_bind_int64(compiledStatement, 1, [contact.UNIQUE_ID integerValue]);
            sqlite3_bind_text(  compiledStatement, 1, [contact.UNIQUE_ID UTF8String], -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(  compiledStatement, 2, [contact.PHONE UTF8String], -1, SQLITE_TRANSIENT);
            NSString *boolValue = (contact.SYNCED?@"YES":@"NO");
            sqlite3_bind_text(compiledStatement, 3, [boolValue UTF8String], -1, SQLITE_TRANSIENT);
            
            while(YES){
                NSInteger result = sqlite3_step(compiledStatement);
                if(result == SQLITE_DONE){
                    break;
                }else if(result != SQLITE_BUSY){
                    printf("db error: %s\n", sqlite3_errmsg(database));
                    break;
                }
            }
            sqlite3_reset(compiledStatement);
        }
        
        
        // COMMIT
        query = @"COMMIT TRANSACTION";
        sqlite3_stmt *commitStatement;
        if (sqlite3_prepare_v2(database, [query UTF8String], -1, &commitStatement, NULL) != SQLITE_OK) {
            printf("db error: %s\n", sqlite3_errmsg(database));
        }
        if (sqlite3_step(commitStatement) != SQLITE_DONE) {
            printf("db error: %s\n", sqlite3_errmsg(database));
        }
        
        sqlite3_finalize(beginStatement);
        sqlite3_finalize(compiledStatement);
        sqlite3_finalize(commitStatement);
        
        [self closeConnection];
    }
}


//Method to execute query
-(NSMutableArray *)executeQuery:(NSString *)query{
    
    NSMutableArray *dataArray = [[NSMutableArray alloc]init];
    
    //getting DBPath
    NSString *dbFilePath = [self getDBFilePath];

    //getting Connection
    BOOL connection = [self getConnection:[dbFilePath UTF8String]];
    
    
    if (connection) {
        
        //Creating statement
        BOOL statementSuccess = [self createStatement:query];
        
        
        if (statementSuccess) {
            
            while (sqlite3_step(statement)== SQLITE_ROW) {
                
                int noOfColumns = sqlite3_data_count(statement);
                NSLog(@"no of rows in database is %d",sqlite3_data_count(statement));
                
                DBContacts *contact = [[DBContacts alloc] init];
                
                for (int i = 0; i< noOfColumns;i++) {
                    NSString *columnValue = [[NSString alloc] initWithUTF8String:(const char*) sqlite3_column_text(statement,i)];
                    
                    NSLog(@"colmn value is %@",columnValue);
                    //NSLog(@"table column name is %@",[[NSString alloc] initWithUTF8String:(const char*) sqlite3_column_table_name(statement,i)]);
                    
                    NSLog(@"table column name %@",[[NSString alloc] initWithUTF8String:(const char*) sqlite3_column_name(statement, i)]);
                    
                    NSString *columnKey = [[NSString alloc] initWithUTF8String:(const char*) sqlite3_column_name(statement, i)];
                    
                    
                    [contact setValue:columnValue forKey:columnKey];
                    
                }
                [dataArray addObject:contact];
            }
            sqlite3_finalize(statement);
        }
        
        sqlite3_close(database);
    }
    return dataArray;
}







@end