//
//  DBContacts.h
//  Boku
//
//  Created by Ghanshyam on 8/19/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DBContacts : NSObject

@property (nonatomic,strong)    NSNumber    *ID;
@property (nonatomic,strong)    NSString    *UNIQUE_ID;
@property (nonatomic,strong)    NSString    *PHONE;
@property (nonatomic,assign)    BOOL        SYNCED;

@end
