//
//  DBContacts.m
//  Boku
//
//  Created by Ghanshyam on 8/19/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "DBContacts.h"

@implementation DBContacts

@end
